

/*
Procedimiento para borrar una linea de pedido, y que llama al metodo necesario para actualizar el campo totalPedido
del pedido al que pertenece
Entradas: un entero como id de la linea de pedido a borrar
*/
CREATE PROCEDURE pr_borrarLineaDePedido @Id_Pedido int, @ID_Producto int, @exito bit OUTPUT
AS
BEGIN

	DECLARE @filasAfectadas int
	DECLARE @Cantidad int
	DECLARE @Fecha smalldatetime

	SET @Fecha = (SELECT Fecha_Entrega FROM Pedidos WHERE Id = @Id_Pedido)

	IF (@Fecha IS NOT NULL)
	BEGIN
		SET @exito = 0
	END
	ELSE
	BEGIN

		SET @Cantidad = (SELECT Cantidad FROM LineasDePedido WHERE Id_Pedido = @Id_Pedido AND Id_Producto = @ID_Producto)

		DELETE FROM LineasDePedido WHERE Id_Pedido=@Id_Pedido AND Id_Producto=@ID_Producto

		SET @filasAfectadas = @@ROWCOUNT

		IF (@filasAfectadas > 0)
		BEGIN
			SET @exito = 1
			EXEC dbo.pr_actualizarTotalPedido @Id_pedido
			EXEC pr_actualizarStockProducto @ID_Producto, @Cantidad, @exito
		END
		ELSE
		BEGIN
			SET @exito = 0
		END
	END


	RETURN


END

go

