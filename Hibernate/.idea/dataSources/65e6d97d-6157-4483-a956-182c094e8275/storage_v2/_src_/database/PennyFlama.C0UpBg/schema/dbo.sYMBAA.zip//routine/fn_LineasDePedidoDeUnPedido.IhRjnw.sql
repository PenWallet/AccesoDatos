
--Funcion que devuelve todas las lineas de pedido de un pedido

CREATE FUNCTION fn_LineasDePedidoDeUnPedido (@ID_Pedido int)
RETURNS TABLE AS
RETURN
(
SELECT *
	FROM LineasDePedido AS LP 
		INNER JOIN Productos AS P 
			ON LP.Id_Producto = P.Id
	WHERE Id_Pedido=@ID_Pedido
)

go

