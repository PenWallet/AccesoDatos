

CREATE PROCEDURE pr_actualizarStockProducto @ID_Producto int, @cantidad int, @exito bit OUTPUT
AS
BEGIN

	DECLARE @filasAfectadas int

	UPDATE Productos
	SET Stock=Stock+@cantidad
	WHERE Id = @ID_Producto

	SET @filasAfectadas = @@ROWCOUNT

	IF (@filasAfectadas > 0)
	BEGIN
		SET @exito = 1
	END
	ELSE
	BEGIN
		SET @exito = 0
	END

	RETURN

END

go

