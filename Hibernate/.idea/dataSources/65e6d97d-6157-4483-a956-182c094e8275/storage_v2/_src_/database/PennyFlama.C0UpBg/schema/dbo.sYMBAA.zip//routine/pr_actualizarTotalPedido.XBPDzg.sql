

/*
Procedimiento para actualizar el campo totalPedido de un pedido.
Entradas: 
*/
CREATE PROCEDURE pr_actualizarTotalPedido @Id_Pedido int
AS
BEGIN

	DECLARE @nuevoTotal AS money
	SET @nuevoTotal = 
	(	
		SELECT ISNULL(SUM(Subtotal), 0)
				FROM LineasDePedido
				WHERE Id_Pedido = @Id_Pedido
    )

	UPDATE Pedidos
	SET Total_Pedido = @nuevoTotal

END

go

