
/*
Procedimiento para actualizar una nueva linea de pedido
Entradas: 
*/
CREATE PROCEDURE pr_actualizarLineaPedido  @Id_Pedido int, @Id_Producto int,
	@Precio_Unitario smallmoney, @Cantidad int, @Impuestos decimal(3,2), @Subtotal money, @exito bit OUTPUT
AS
BEGIN

	DECLARE @filasAfectadas int
	DECLARE @CantidadAntigua int
	DECLARE @CantidadModificar int

	SET @CantidadAntigua = (SELECT Cantidad FROM LineasDePedido WHERE Id_Pedido = @Id_Pedido AND Id_Producto = @Id_Producto)
	SET @CantidadModificar = (@Cantidad - @CantidadAntigua)*(-1)

	EXECUTE pr_actualizarStockProducto @ID_Producto, @CantidadModificar, @exito = @filasAfectadas OUTPUT

	IF (@filasAfectadas = 0)
	BEGIN
		SET @exito = 0
	END
	ELSE
	BEGIN

		UPDATE LineasDePedido
			SET Id_Producto = @Id_Producto,
				Precio_Unitario = @Precio_Unitario,
				Cantidad = @Cantidad,
				Impuestos = @Impuestos,
				Subtotal = @Subtotal
			WHERE Id_Pedido = @Id_Pedido AND Id_Producto = @Id_Producto

		SET @filasAfectadas = @@ROWCOUNT

		IF (@filasAfectadas > 0)
		BEGIN
			SET @exito = 1
			EXEC dbo.pr_actualizarTotalPedido @Id_pedido
		END
		ELSE
		BEGIN
			SET @exito = 0
		END
	END

	RETURN

END

go

