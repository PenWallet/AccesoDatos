
CREATE PROCEDURE pr_actualizarPedido @ID_Pedido int, @ID_Cliente int, @Username_Vendedor varchar(60),
	@Fecha_Pedido smalldatetime, @Fecha_Entrega smalldatetime, @Total_Pedido money, @exito bit OUTPUT
AS
BEGIN

	DECLARE @filasAfectadas int
	
	UPDATE Pedidos
	SET Id_Cliente = @ID_Cliente,
	Username_Vendedor = @Username_Vendedor,
	Fecha_Pedido = @Fecha_Pedido,
	Fecha_Entrega = @Fecha_Entrega,
	Total_Pedido = @Total_Pedido
	WHERE Id = @ID_Pedido

	SET @filasAfectadas = @@ROWCOUNT

	IF (@filasAfectadas > 0)
	BEGIN
		SET @exito = 1
	END
	ELSE
	BEGIN
		SET @exito = 0
	END

	RETURN

END

go

