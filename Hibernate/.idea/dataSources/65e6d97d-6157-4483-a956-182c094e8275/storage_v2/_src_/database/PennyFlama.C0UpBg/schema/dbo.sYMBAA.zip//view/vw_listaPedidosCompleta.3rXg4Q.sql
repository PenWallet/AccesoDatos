
--Vista con todos los pedidos

CREATE VIEW vw_listaPedidosCompleta AS
SELECT Id, Id_Cliente, Username_Vendedor, Fecha_Pedido, Fecha_Entrega, Total_Pedido FROM Pedidos

go

