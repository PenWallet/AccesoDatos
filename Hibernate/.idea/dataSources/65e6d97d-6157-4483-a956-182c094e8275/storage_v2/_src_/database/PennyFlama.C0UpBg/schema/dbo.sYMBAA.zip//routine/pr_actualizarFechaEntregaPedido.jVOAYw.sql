
/*
Procedimiento para actualizar la fecha de entrega de un pedido existente
Entradas: un entero como id del pedido a actualizar, smalldatetime para la fecha
*/
CREATE PROCEDURE pr_actualizarFechaEntregaPedido @Id_Pedido int, @fecha smalldatetime=NULL
AS
BEGIN

	IF (@fecha IS NULL)
	BEGIN
		SET @fecha = CURRENT_TIMESTAMP
	END

	UPDATE Pedidos
	SET Fecha_Entrega = @fecha
	WHERE Id = @Id_Pedido

END

go

