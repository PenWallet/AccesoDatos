
--Vista con todos los clientes

CREATE VIEW vw_ListaClientesCompleta AS
SELECT Id, Nombre FROM Clientes


go

