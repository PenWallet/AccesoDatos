

/*
Procedimiento para insertar un nuevo pedido
Entradas: entero para id del cliente, cadena para username del vendedor, smalldatetime para fecha de pedido y entrega, y money para el total del pedido
Salidas: un BIT para indicar si la insercion se ha realizado correctamente o si ha sucedido algún problema
*/
CREATE PROCEDURE pr_insertarNuevoPedido @Id_Cliente int, @Username_Vendedor nvarchar(60), @exito bit OUTPUT
AS
BEGIN

	DECLARE @filasAfectadas int

	INSERT INTO Pedidos
	(Id_Cliente, Username_Vendedor, Fecha_Pedido, Fecha_Entrega, Total_Pedido)
	VALUES
	(@Id_Cliente, @Username_Vendedor, CURRENT_TIMESTAMP, NULL, 0)

	SET @filasAfectadas = @@ROWCOUNT

	IF (@filasAfectadas > 0)
	BEGIN
		SET @exito = 1
	END
	ELSE
	BEGIN
		SET @exito = 0
	END

	RETURN

END

go

