
/*
Procedimiento para insertar una nueva linea de pedido
Entradas: 
*/
CREATE PROCEDURE pr_insertarNuevaLineaDePedido @Id_Pedido int, @Id_Producto int,
	@Precio_Unitario smallmoney, @Cantidad int, @Impuestos decimal(3,2), @Subtotal money, @exito bit OUTPUT
AS
BEGIN

	DECLARE @filasAfectadas int
	DECLARE @CantidadNegativa int

	SET @CantidadNegativa = @Cantidad*(-1)

	--Restar cantidad de producto a comprar del stock. Si no hay suficiente stock, no se realizarán las operaciones.
	EXECUTE pr_actualizarStockProducto @ID_Producto, @CantidadNegativa, @exito = @filasAfectadas OUTPUT

	IF (@filasAfectadas = 0)
	BEGIN
		SET @exito = 0
	END
	ELSE
	BEGIN
		INSERT INTO LineasDePedido
		(Id_Pedido, Id_Producto, Precio_Unitario, Cantidad, Impuestos, Subtotal)
		VALUES
		(@Id_Pedido,@Id_Producto, @Precio_Unitario, @Cantidad, @Impuestos, @Subtotal)

		SET @filasAfectadas = @@ROWCOUNT

		IF (@filasAfectadas > 0)
		BEGIN
			SET @exito = 1
			EXEC dbo.pr_actualizarTotalPedido @Id_pedido
		END
		ELSE
		BEGIN
			SET @exito = 0
		END
	END


	

	RETURN

END

go

