
--Vista con todos los productos

CREATE VIEW vw_ListaProductosCompleta AS
SELECT Id, Nombre, Precio_venta, Descripcion, Stock FROM Productos

go

